package com.example.s8088576_assignment1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.annotation.DrawableRes

// A simple data class to hold song information
data class Song(
    val title: String,
    val artist: String,
    @DrawableRes val imageResource: Int)

class SongAdapter(private val songList: List<Song>) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    // This class holds the views for a single item in the list
    class SongViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val albumArt: ImageView = itemView.findViewById(R.id.album_art_image_view)
        val songTitle: TextView = itemView.findViewById(R.id.song_title_text_view)
        val artistName: TextView = itemView.findViewById(R.id.artist_name_text_view)
    }

    // Creates a new ViewHolder (a new 'item_song_card.xml' layout)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_song_card, parent, false)
        return SongViewHolder(view)
    }

    // Binds the data from the songList to the views in the ViewHolder
    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songList[position]
        holder.songTitle.text = song.title
        holder.artistName.text = song.artist
    }

    // Returns the total number of items in the list
    override fun getItemCount() = songList.size
}
    