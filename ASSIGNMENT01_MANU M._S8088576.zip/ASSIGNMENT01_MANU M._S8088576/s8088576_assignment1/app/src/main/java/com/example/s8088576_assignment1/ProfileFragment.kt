package com.example.s8088576_assignment1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the RecyclerView from the layout
        val recentlyPlayedRecyclerView: RecyclerView = view.findViewById(R.id.profile_recently_played_recycler)

        // Create some placeholder data (you can change this later with real images)
        // Since you haven't added unique images yet, we'll use the placeholder for all.
        val recentlyPlayedSongs = listOf(
            Song("Eternal Atake", "Lil Uzi Vert", R.drawable.placeholder_album_art),
            Song("French Exit", "TV Girl", R.drawable.placeholder_album_art),
            Song("Happier Than Ever", "Billie Eilish", R.drawable.placeholder_album_art)
        )

        // Create and set the adapter (we can reuse the same SongAdapter)
        recentlyPlayedRecyclerView.adapter = SongAdapter(recentlyPlayedSongs)

        // --- Back Button Functionality ---
        val backButton: View = view.findViewById(R.id.back_arrow)
        backButton.setOnClickListener {
            // This will take the user back to the previous screen (Home)
            findNavController().navigateUp()
        }
    }
}
