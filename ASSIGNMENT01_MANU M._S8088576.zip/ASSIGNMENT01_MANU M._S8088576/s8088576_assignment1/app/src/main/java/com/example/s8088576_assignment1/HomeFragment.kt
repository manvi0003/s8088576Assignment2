package com.example.s8088576_assignment1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the RecyclerViews from the layout
        val recentlyPlayedRecyclerView: RecyclerView = view.findViewById(R.id.recently_played_recycler_view)
        val trendingNowRecyclerView: RecyclerView = view.findViewById(R.id.trending_now_recycler_view)

        // Create some placeholder data, including a drawable resource for each song
        // Note: You should replace these with your actual drawable resources.
        val recentlyPlayedSongs = listOf(
            Song("Certified Lover Boy", "Drake", R.drawable.ic_launcher_background),
            Song("Die Lit", "Playboi Carti", R.drawable.ic_launcher_background),
            Song("ASTROWORLD", "Travis Scott", R.drawable.ic_launcher_background),
            Song("Midnights", "Taylor Swift", R.drawable.ic_launcher_background)
        )

        val trendingSongs = listOf(
            Song("Whole Lotta Red", "Playboi Carti", R.drawable.ic_launcher_background),
            Song("Eternal Atake", "Lil Uzi Vert", R.drawable.ic_launcher_background),
            Song("DS4EVER", "Future", R.drawable.ic_launcher_background),
            Song("Happier Than Ever", "Billie Eilish", R.drawable.ic_launcher_background)
        )

        // Create and set the adapters
        recentlyPlayedRecyclerView.adapter = SongAdapter(recentlyPlayedSongs)
        trendingNowRecyclerView.adapter = SongAdapter(trendingSongs)
    }
}
