package com.example.s8088576_assignment1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController

class LoginFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment.
        // This line links the Kotlin file to your fragment_login.xml layout.
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the button from the layout using its ID.
        val loginButton = view.findViewById<Button>(R.id.login_button)

        // Set a listener that will execute code when the button is clicked.
        loginButton.setOnClickListener {
            // This command tells the Navigation Component to move to the next screen.
            // The 'action_loginFragment_to_homeFragment' ID is automatically generated
            // from the arrow you drew in your nav_graph.
            findNavController().navigate(R.id.action_loginFragment_to_homeFragment)
        }
    }
}
