package com.example.s8088576_assignment1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.navigation.fragment.findNavController

class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // --- Setup Spinner (Dropdown) ---
        val equalizerSpinner: Spinner = view.findViewById(R.id.equalizer_spinner)

        // Create a list of items for the spinner
        val equalizerOptions = arrayOf("Adaptive (AI-Powered)", "Bass Boost", "Vocal Focus", "Flat")

        // Create an ArrayAdapter using the string array and a default spinner layout
        // 'requireContext()' is used to get the context safely within a Fragment
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item, // This is a default layout provided by Android
            equalizerOptions
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            equalizerSpinner.adapter = adapter
        }

        // --- Back Button Functionality ---
        val backButton: View = view.findViewById(R.id.back_arrow)
        backButton.setOnClickListener {
            // This will take the user back to the previous screen (Home)
            findNavController().navigateUp()
        }
    }
}
